// 手写类型声明(包用 esbuild 构建,不跑 dts 生成,保持工具链最小)。
// 新增导出时同步维护本文件。
import type { DefineComponent, Ref } from 'vue'

export interface BrandThemeManifest {
  schemaVersion: number
  themeId: string
  validDate: string
  accent?: string
  accentDark?: string
  title?: string
  copy?: string
  assets?: Record<string, string>
}

export interface BrandThemeState {
  loaded: boolean
  theme: BrandThemeManifest | null
  heroImage: string | null
  error: string | null
}

export interface BrandThemeOptions {
  appId: string
  portalBase?: string
  refreshMinutes?: number
}

export type ColorScheme = 'light' | 'dark' | 'auto'

export declare function initBrandTheme(
  options: BrandThemeOptions,
): Readonly<BrandThemeState>
export declare function useBrandTheme(): Readonly<BrandThemeState>
export declare function initColorScheme(): ColorScheme
export declare function setColorScheme(scheme: ColorScheme): void
export declare function currentColorScheme(): ColorScheme

export interface PortalApp {
  id: string
  name: string
  href: string
  icon?: string
  desc?: string
}

export interface PortalUser {
  name: string
  role?: string
}

export interface PortalSession {
  loaded: boolean
  authenticated: boolean
  user: PortalUser | null
  apps: PortalApp[]
  error: string | null
}

export declare function usePortalSession(
  portalBase?: string,
): Readonly<PortalSession>

export interface SideNavItem {
  key: string
  label: string
  href?: string
  icon?: string
}

export declare const AppShell: DefineComponent<{
  appId: string
  appName: string
  hasSidenav?: boolean
  portalBase?: string
}>
export declare const TopBar: DefineComponent<{
  appId: string
  appName: string
  portalBase?: string
  showNavToggle?: boolean
}>
export declare const SideNav: DefineComponent<{
  items: SideNavItem[]
  active?: string
  collapsible?: boolean
}>
export declare const AppSwitcher: DefineComponent<{
  appId: string
  portalBase?: string
}>
export declare const UserMenu: DefineComponent<{
  portalBase?: string
  logoutHref?: string
}>

export declare const naiveThemeOverrides: Record<string, unknown>
export declare const naiveDarkThemeOverrides: Record<string, unknown>
